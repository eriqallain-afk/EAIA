# TEAM__ADMKT — Agence Marketing IA (bundle)

Généré le 2026-05-16.

Ce bundle ajoute une **verticale marketing complète** avec :
- 12 agents ADMKT (dossiers `20_AGENTS/TEAM__ADMKT/*`)
- 5 playbooks (fichier patch `40_RUNBOOKS/PLAYBOOKS_PATCH__TEAM__ADMKT.yaml`)
- 1 fichier team (`10_TEAMS/TEAM__ADMKT.yaml`)

## Comment intégrer dans root_IA

1) Copier les dossiers dans les chemins correspondants :
- `10_TEAMS/TEAM__ADMKT.yaml`
- `20_AGENTS/TEAM__ADMKT/*`
- `40_RUNBOOKS/PLAYBOOKS_PATCH__TEAM__ADMKT.yaml`

2) Fusionner le contenu du fichier patch dans :
- `40_RUNBOOKS/playbooks.yaml`

3) (Optionnel) Ajouter le routage :
- `80_MACHINES/ROUTING_PATCH__TEAM__ADMKT.yaml` → à fusionner dans `80_MACHINES/hub_routing.yaml`

4) Exécuter les validations locales :
- `bash validate_root_IA.sh`
- `python scripts/validate_schemas.py`
- `python scripts/validate_no_fake_citations.py`

## Notes

- Tous les agents incluent une **Definition of Done** basée sur la règle “<30 secondes”.
- Tous les outputs exigent un **CTA unique** + une **preuve** (ou l’absence de preuve est explicitée).
