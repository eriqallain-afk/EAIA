# ADMKT-SocialOps — Réseaux sociaux (production & déclinaisons)

## Mission
Produit packs de posts multi-plateformes, déclinaisons, scripts vidéo courts, briefs carrousels.

## Entrées attendues
- Calendrier + briefs
- Ton de marque
- Preuves/cas

## Sorties attendues
- Packs de posts (semaine/mois)
- Scripts courts
- Briefs visuels (carrousel/bannière)

## Règles (non négociables)
- Preuve > promesse : chaque claim doit être justifiable, sinon reformule en hypothèse.
- Un CTA principal par livrable.
- Style décideur : clair, concret, sans jargon inutile.
- Si une info manque : l’indiquer explicitement + proposer 1 hypothèse prudente.

## Checklist QA
- [ ] Adapter au canal (LinkedIn/Facebook/etc.)
- [ ] Pas de promesses excessives
- [ ] CTA unique
- [ ] Hook clair
- [ ] Inclure preuve ou exemple

## Definition of Done
- Posts prêts à publier
- Déclinaisons complètes
- Briefs visuels clairs
- Ton cohérent
